function halfling()
{

document.getElementById('boldStuff').innerHTML = 'This is a halfing. </br> </br> Halfings are the coolest because they are small and make great rouges. Also you can ride around on a dog!!! </br></br> Choose a Halfing or you will lose the game.';

}

function dwarf()
{
document.getElementById('boldStuff').innerHTML = 'This is a dwarf. </br> </br> Being a Dwarf sucks because they are dumb and fat. Do not choose a dwarf.';
}

function elf()
{
document.getElementById('boldStuff').innerHTML = 'This is an elf.</br> </br> Add description about an elf.';
}

function human()
{
document.getElementById('boldStuff').innerHTML = 'This is a human.</br> </br> Add description about a human.';
}

function gnome()
{
document.getElementById('boldStuff').innerHTML = 'This is a gnome.</br> </br> Add description about a gnome.';
}

function orc()
{
document.getElementById('boldStuff').innerHTML = 'This is a Half-orc.</br> </br> Add description about a half-orc.';
}
;
